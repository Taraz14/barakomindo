</div>
<!-- /.content-wrapper -->
<footer class="main-footer">
  <div class="pull-right hidden-xs">
    <b>Version</b> 1.0
  </div>
  <strong>Copyright &copy; 2020 <a href="https://github.com/taraz14">Barakomindo</a>.</strong> All rights
  reserved.
</footer>