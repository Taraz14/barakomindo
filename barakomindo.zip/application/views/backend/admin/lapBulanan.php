<style>
  table th:nth-child(3),
  td:nth-child(3) {
    display: none;
  }

  .test {
    width: 50px;
    float: left;
  }
</style>
<section class="content">
  <div class="row">
    <div class="col-lg-3 col-xs-6">
      <div class="small-box bg-red">
        <div class="inner">
          <h3><?= $countPegawai ?></h3>

          <p>Pegawai</p>
        </div>
        <div class="icon">
          <i class="fa fa-users" style="font-size:80%;"></i>
        </div>
      </div>
    </div>
    <div class="col-lg-3 col-xs-6">
      <div class="small-box bg-yellow">
        <div class="inner">
          <h3><?= $countCert; ?></h3>

          <p>Sertifikat</p>
        </div>
        <div class="icon">
          <i class="fa fa-file-text-o" style="font-size:80%;"></i>
        </div>
      </div>
    </div>
    <div class="col-lg-3 col-xs-6">
      <div class="small-box bg-green">
        <div class="inner">
          <h3><?= $countFkapal ?></h3>

          <p>Foto Kapal</p>
        </div>
        <div class="icon">
          <i class="fa fa-picture-o" style="font-size:80%;"></i>
        </div>
      </div>
    </div>
    <div class="col-lg-3 col-xs-6">
      <div class="small-box bg-blue">
        <div class="inner">
          <h3><?= date('M'); ?></h3>

          <p>Bulan</p>
        </div>
        <div class="icon">
          <i class="fa fa-bar-chart" style="font-size:80%;"></i>
        </div>
      </div>
    </div>
    <!-- laporan -->
    <div class="col-md-12">
      <div class="box box-primary">
        <div class="box-header with-border">
          <h3 class="box-title">
            Laporan Bulanan
          </h3>
        </div>
        <form action="">
          <div class="box-body">
            <table class="table table-bordered table-hover nowrap" id="lapBulanan">
              <thead>
                <th>No.</th>
                <th>Nama Kapal</th>
                <th>Nama Sertifikat</th>
                <th>Uploaded By</th>
                <th>Aksi</th>
              </thead>
            </table>
          </div>
        </form>
      </div>
    </div>
  </div>
</section>
<script>
  $(function() {
    $('#lapBulanan').DataTable({
      responsive: true,
      "dom": '<"wrapper"f<"test">lipt>'
    });
    $('.test').html("<select class='form-control'><option>2020</option><option>2021</option></select>");
  });
</script>